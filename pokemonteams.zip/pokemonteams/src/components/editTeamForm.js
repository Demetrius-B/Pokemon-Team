import React, { Component } from 'react';

class editTeamForm extends Component {

    render(){
        return(
            <div className="editTeam" onSubmit={this.editForm}>
                <form className="editTeamForm">
                
                </form>
            </div>
        );
    }
}
